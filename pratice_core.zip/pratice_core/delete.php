<?php
include 'connection.php';
$id = $_GET['delete'];
$sql = "delete from `user` where `user_id` = '$id'";
$ex = $conn -> query($sql);
if($ex)
{
	header('location:showdata.php');
}
else
{
	echo"error";
}
?>
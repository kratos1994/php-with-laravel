<?php
require 'connection.php';

if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$dob=$_POST['dob'];
	$gender=$_POST['gender'];
	$number=$_POST['mobile'];
	$hobbies=implode(',', $_POST['hby']);

	$image=$_FILES['image']['name'];
	$size=$_FILES['image']['size'];
	$type=$_FILES['image']['type'];
	$path=$_FILES['image']['tmp_name'];
	$new_path=("image/".$image);
	move_uploaded_file($path, $new_path);
}
  $sql = "INSERT INTO `user`( `user_name`,`user_email`,`user_password`, `user_dob`, `user_gender`, `user_hobbies`, `user_number`, `user_image` ) values ('$name','$email','$password', '$dob','$gender','$hobbies', '$number', '$image')";
  $ex = $conn -> query($sql);
  if ($ex) 
  {
  	header('location:showdata.php');
  }
  else 
  {
  	echo "error";
  }
  
?>
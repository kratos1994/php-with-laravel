<?php
$conn = new mysqli("localhost", "root", "", "core");

if($conn == true)
{
	echo "connected";
}
else
{
	echo "error";
}

?>
<?php
include 'connection.php';
$sql = "SELECT * FROM `user`";
$ex = $conn->query($sql);
?>

<table border="2" cellpadding="2" cellspacing="2">
	<tr>
		<th>Name</th>
		<th>Email</th>
		<th>Password</th>
		<th>Date of Birth</th>
		<th>Gender</th>
		<th>Hobbies</th>
		<th>Mobile Number</th>
		<th>Image</th>
		<th colspan="2">Action</th>
		<?php
		while($data = mysqli_fetch_object($ex))
		{
			// print_r($data);
			echo "<tr>
			<td>$data->user_name</td>
			<td>$data->user_email</td>
			<td>$data->user_password</td>
			<td>$data->user_dob</td>
			<td>$data->user_gender</td>
			<td>$data->user_hobbies</td>
			<td>$data->user_number</td>
			<td><img src='image/$data->user_image' height='100'></td>
			<td><a href='delete.php?delete=$data->user_id'>Delete</td>
			<td><a href='update.php?update=$data->user_id'>Update</td>
			</tr>";
		}
		?>
	</tr>
</table>
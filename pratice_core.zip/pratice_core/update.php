<?php
require 'connection.php';
$id = $_GET['update'];
echo $sql= "select * from `user` where `user_id`='$id'";
$ex = $conn->query($sql);

if(isset($_POST['edit']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$dob=$_POST['dob'];
	$gender=$_POST['gender'];
	$number=$_POST['mobile'];
	$hobbies=implode(',', $_POST['hby']);
	if($_FILES['image']['name'])
	{
		$image=$_FILES['image']['name'];
		$size=$_FILES['image']['size'];
		$type=$_FILES['image']['type'];
		$path=$_FILES['image']['tmp_name'];
		$new_path=("image/".$image);
		move_uploaded_file($path, $new_path);
	}
	else
	{
		$image = $_POST['old_image'];
	}
	

	echo $sql = "update `user` SET 
			`user_name` = '$name',
			`user_email` = '$email',
			`user_password` = '$password',
			`user_dob` = '$dob',
			`user_gender` = '$gender',
			`user_number` = '$number',
			`user_hobbies` = '$hobbies',
			`user_image` = '$image' 
										WHERE `user_id` = '$id'";
	$ex1 = $conn->query($sql);
	if ($ex1)
	{
		header('location:showdata.php');
	} 
	else
	{
		echo "error";
	}
}
	?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><?php
while ($res=mysqli_fetch_object($ex)) {?>
	<form method="POST" action="" enctype="multipart/form-data">
<table border="2" cellspacing="2" cellpadding="2">
<tr>
	<th>Full Name</th>
	<td><input type="text" name="name" value="<?php echo $res->user_name;?>"></td>
</tr>
<tr>
	<th>Email</th>
	<td><input type="email" name="email" value="<?php echo $res->user_email;?>"></td>
</tr>
<tr>
	<th>Password</th>
	<td><input type="text" name="password" value="<?php echo $res->user_password;?>"></td>
</tr>
<tr>
	<th>Date of Birth</th>
	<td><input type="date" name="dob" value="<?php echo $res->user_dob;?>"></td>
</tr>
<tr>
	<th>Gender</th>
	<td><input type="radio" name="gender" <?php if($res->user_gender == 'male'){ echo "checked"; }?> value="male">Male
		<input type="radio" name="gender" <?php if($res->user_gender == 'female'){ echo "checked"; }?> value="female">Female
	</td>
</tr>
<tr>
	<th>hobbies</th>
	<td><?php 	$hobbies=explode(',', $res->user_hobbies);?>
		<input type="checkbox" name="hby[]" <?php if(in_array("php",$hobbies)){echo "checked";}?> value="php">PHP
		<input type="checkbox" name="hby[]" <?php if(in_array("java",$hobbies)){echo "checked";}?> value="java">Java
		<input type="checkbox" name="hby[]" <?php if(in_array("net",$hobbies)){echo "checked";}?> value="net">Dot Net
	</td>
</tr>
<tr>
	<th>Mobile Number</th>
	<td><input type="number" name="mobile" value="<?php echo $res->user_number;?>"></td>
</tr>
<tr>
	<th>Current_image</th>
	<td><input type="text" name="old_image" value="<?php echo $res->user_image;?>"></td>
	<td><img src="image/<?php echo $res->user_image?>"></td>
</tr>
<tr>
	<th>Change Image</th>
	<td><input type="file" name="image"></td>
</tr>
<tr>
	<th><?php echo " "?></th>
	<td><input type="submit" name="edit" value="edit"></td>
</tr>
</table>
</form>
<?php }


?>

</body>
</html>